<div style="font-family:Arial,sans-serif;max-width:520px;color:#16263f">
<h2>Update on <?php echo e($application->reference); ?></h2>
<p>Hi <?php echo e($application->first_name); ?>, your application status is now: <b><?php echo e($application->status_label); ?></b>.</p>
<?php if($note): ?><p style="white-space:pre-wrap"><?php echo e($note); ?></p><?php endif; ?>
<p><a href="<?php echo e(config('program.frontend_url')); ?>/status">View full status</a></p>
<p style="font-size:13px;color:#667">We never ask for passwords, PINs, card numbers, one-time codes or upfront fees.</p></div>
<?php /**PATH /Users/mac/Downloads/refund/backend/resources/views/mail/status.blade.php ENDPATH**/ ?>