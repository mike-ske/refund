<?php
/** @var \Laravel\Boost\Install\GuidelineAssist $assist */
$pest = $assist->hasPackage('pestphp/pest');
?>
# Security tests

Test each security boundary where user input affects authorization, rendered output, or query construction. A defect at such a boundary is hard to detect, because the feature can keep working.

Write a test for each of these cases:

- **Cross-tenant access.** Request a record of a different tenant, team, or organization. Read ___SINGLE_BACKTICK___rules/endpoint-tests.md___SINGLE_BACKTICK___ for when the response should be ___SINGLE_BACKTICK___404___SINGLE_BACKTICK___ rather than ___SINGLE_BACKTICK___403___SINGLE_BACKTICK___.
<?php if($pest): ?>
- **Each unprivileged role.** Use a dataset over the roles that the endpoint must refuse.
<?php else: ?>
- **Each unprivileged role.** Use a data provider over the roles that the endpoint must refuse.
<?php endif; ?>
- **Escaping user-provided content.** Test escaping in HTML and mail. Include names and every free-text field a template renders. Assert that dangerous characters are escaped and the raw value is absent. Do not assert an exact entity for a quote, because Markdown and mail CSS inliners can decode it.
- **Injection into dynamic query components.** Examples include sort columns, filter fields, and sort directions.
- **An unexpected key** in a payload or configuration array. A merge that accepts every key can set an attribute the user must not control.

<?php if($pest): ?>
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___php
it('escapes dangerous content in the notification', function () {
    $organization = Organization::factory()->make([
        'name' => "O'Reilly <script>alert('xss')</script>",
    ]);

    $content = (new QuotaApproaching($organization, 80))->toMail()->render();

    expect($content)
        ->toContain('___AMPERSAND___lt;script___AMPERSAND___gt;')
        ->not->toContain("<script>alert('xss')</script>");
});
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___
<?php else: ?>
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___php
public function test_escapes_dangerous_content_in_the_notification(): void
{
    $organization = Organization::factory()->make([
        'name' => "O'Reilly <script>alert('xss')</script>",
    ]);

    $content = (new QuotaApproaching($organization, 80))->toMail()->render();

    $this->assertStringContainsString('___AMPERSAND___lt;script___AMPERSAND___gt;', $content);
    $this->assertStringNotContainsString("<script>alert('xss')</script>", $content);
}
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___
<?php endif; ?>

Laravel provides defenses against mass assignment, unauthorized access, and unescaped output. Test that the application applies the correct defense to each attribute, route, and template.
<?php /**PATH /Users/mac/Downloads/refund/backend/storage/framework/views/3abfd53794fadab95eca813f28f5646e.blade.php ENDPATH**/ ?>